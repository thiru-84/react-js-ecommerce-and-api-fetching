

function Message() {
  return (
    <>
      <div className=" container mx-auto">
        <h1>Good Morning</h1>
        <p>Explore the world of React</p>
      </div>
    </>
  )
}

export default Message
