import { useState, useEffect } from "react";

function Items() {
  const [photos, setPhotos] = useState([]);
  const [title, setTitle] = useState([]);
  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        // console.log(data);
        setPhotos(data);
        setTitle(data);
        // console.log("title :" + setPhotos.map());
      });
  }, []);

  return (
    <>
      <div className="container grid mx-auto place-items-center pt-18">
        <div className="flex flex-col  justify-center mx-auto">
          <div>
            <h2 className="text-2xl font-bold pb-6">Deals of the Day</h2>
          </div>

         
          {/* card 1 */}
          <div className="flex flex-wrap justify-center">
            <div className="max-w-sm overflow-hidden border border-gray-200 ">
              {photos.map((photo) => (
                <img
                  key={photo.id}
                  src={photo.image}
                  alt={photo.title}
                  width={100}
                />
              ))}
              
              {photos.map((photo) => (
                <div className=" text-lg  mb-2">{photo.title}</div>
              ))}
            
              <div className="px-4 py-4">
                <div className=" text-lg  mb-2">Example</div>
              </div>
              <div className="flex justify-between items-center px-4 pt-2 pb-6">
                <div className="text-3xl ">$50</div>

                <div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="size-10"
                  >
                    <path
                      fillRule="evenodd"
                      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 9a.75.75 0 0 0-1.5 0v2.25H9a.75.75 0 0 0 0 1.5h2.25V15a.75.75 0 0 0 1.5 0v-2.25H15a.75.75 0 0 0 0-1.5h-2.25V9Z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>


        <div className="flex flex-col mt-18 justify-center mx-auto">
          <div>
            <h2 className="text-2xl font-bold pb-6">Deals of the Day</h2>
          </div>

          {/* card 1 */}
          <div className="flex flex-wrap justify-center">
            <div className="max-w-sm overflow-hidden border border-gray-200 ">
              <img
                className="w-full"
                src="https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Sunset in the mountains"
              />
              <div className="px-4 py-4">
                <div className=" text-lg  mb-2">Example</div>
              </div>
              <div className="flex justify-between items-center px-4 pt-2 pb-6">
                <div className="text-3xl ">$50</div>
                <div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="size-10"
                  >
                    <path
                      fillRule="evenodd"
                      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 9a.75.75 0 0 0-1.5 0v2.25H9a.75.75 0 0 0 0 1.5h2.25V15a.75.75 0 0 0 1.5 0v-2.25H15a.75.75 0 0 0 0-1.5h-2.25V9Z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
              </div>
            </div>

            {/* card 2 */}
            <div className="max-w-sm overflow-hidden border border-gray-200 ">
              <img
                className="w-full"
                src="https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Sunset in the mountains"
              />
              <div className="px-4 py-4">
                <div className=" text-lg  mb-2">Example</div>
              </div>
              <div className="flex justify-between items-center px-4 pt-2 pb-6">
                <div className="text-3xl ">$50</div>
                <div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="size-10"
                  >
                    <path
                      fillRule="evenodd"
                      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 9a.75.75 0 0 0-1.5 0v2.25H9a.75.75 0 0 0 0 1.5h2.25V15a.75.75 0 0 0 1.5 0v-2.25H15a.75.75 0 0 0 0-1.5h-2.25V9Z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
              </div>
            </div>

            {/* card 3 */}
            <div className="max-w-sm overflow-hidden border border-gray-200 ">
              <img
                className="w-full"
                src="https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                alt="Sunset in the mountains"
              />
              <div className="px-4 py-4">
                <div className=" text-lg  mb-2">Example</div>
              </div>
              <div className="flex justify-between items-center px-4 pt-2 pb-6">
                <div className="text-3xl ">$50</div>
                <div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className="size-10"
                  >
                    <path
                      fillRule="evenodd"
                      d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 9a.75.75 0 0 0-1.5 0v2.25H9a.75.75 0 0 0 0 1.5h2.25V15a.75.75 0 0 0 1.5 0v-2.25H15a.75.75 0 0 0 0-1.5h-2.25V9Z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Items;
