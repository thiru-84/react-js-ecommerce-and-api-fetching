import './App.css'
import Nav from './components/Nav'
// import Message from './components/Message'
import Items from './components/Items'

function App() {
 

  return (
    <>
      <Nav />
      {/* <Message /> */}
      <Items />
    </>
  )
}

export default App
